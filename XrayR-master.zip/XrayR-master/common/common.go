// Package common contains common utilities that are shared among other packages.
package common
